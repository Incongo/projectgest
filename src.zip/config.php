<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'projectgest');
define('DB_USER', 'projectgest');
define('DB_PASS', 'projectgest');
define('BASE_URL', '/projectgest/');
